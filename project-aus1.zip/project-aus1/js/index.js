
// navigation hideand show function
function toogleNav() {

    if ( $('#nav-links').css('display') === 'flex'){
       $('#nav-links').css('display','none'); 
        $('#nav-links').css('animation', 'slideOutNav 0.3s ease-out');
    }else{
        $('#nav-links').css('display', 'flex'); 
        $('#nav-links').css('animation', 'slideInNav 0.3s ease-in');
    }
} 


     