<template>

    <div class="col-md-8">
        <div class="wrap p-4 mr-none">
            <div class="payment-header clearfix">
                <figure>
                    <img :src="productImage" :alt="product">

                </figure>
                <p class="service-name" v-if="product=='smartcell'">SMART CELL</p>
                <p class="service-name" v-else-if="product=='nt-cdma'">NT CDMA</p>
                <p class="service-name" v-else-if="product=='ntc-prepaid'">NTC PREPAID</p>
                <p class="service-name" v-else-if="product=='ntc-postpaid'">NTC POSTPAID</p>
                <p class="service-name" v-else>{{product.toUpperCase()}}</p>


            </div>

           
            
            <div class="mobile-modal" v-if="mobileVerifyModal == true">
                <div class="mobile-modal-body">
                    <h5>Please Verify Your Mobile Number <i class="fa fa-close" @click="hideMobileModal()"></i></h5>
                    <div class="mobile-main-body">
                        <mobile-component></mobile-component>
                    </div>
                </div>
            </div>
                   
           

            <div class="payment-form">
                <div class="row">
                    <div class="col-md-6">
                        <form>
                            <p v-if="errors.length">
                                <b>Please correct the following error(s):</b>
                            <ul>
                                <li v-for="error in errors" class="error" :key="error">{{ error }}</li>
                            </ul>


                            <div class="form-group">
                                <label for="">Mobile Number *</label>
                                <input type="text" placeholder="e.g:9xxxxxxxxx" class="form-control"
                                       v-model="form.mobile" required>
                            </div>
                            <div class="form-group">
                                <label for="">Amount *</label>
                                <select v-model="form.amount" id="" class="form-control" required>
                                    <option value="200">200</option>
                                    <option value="500">500</option>
                                    <option value="1000">1000</option>
                                    <option value="2000">2000</option>
                                    <option value="2500">2500</option>
<!--                                    <option value="3000">3000</option>-->
<!--                                    <option value="5000">5000</option>-->
                                </select>
                            </div>
                            <div class="form-group">
                                <button type="button" class="btn btn-primary" @click="checkForm">Proceed</button>
                            </div>
                        </form>
                    </div>

                    <div class="col-md-6">
                        <div class="desc-text">
                            <p>Please enter your {{ product | capitalize}} mobile number and select amount to recharge
                                your balance.</p>
                            <p>Taking care of your loved ones has never been so easy</p>
                        </div>
                    </div>
                </div>
            </div>                      
                    


        </div>
        <payment :product="products" :data="form" v-show="isVisible" @close="closeModal"
                 :locationcurrency="locationcurrency"></payment>
    </div>


</template>
<script>
import payment from "../modal/payment";

export default {
    props: {
        product: String,
        currency: String,
        locationcurrency: String
    },
    data() {
        return {
            mobileVerifyModal: false,
            relatedproduct: "",
            productImage: "/img/product/" + this.product + ".jpg",
            form: {
                product: "",
                mobile: "",
                amount: ""
            },
            data: "",
            footer: "",
            errors: [],
            isVisible: false,
            products: {},
            auth: false
        };
    },
    mounted() {
        this.getProductInfo();
        Event.$on(
            "closeModal",
            function() {
                this.closeModal();
            }.bind(this)
        );
        this.checkAuth();
    },
    methods: {
        checkAuth() {
            axios
                .get("/auth/check")
                .then(response => {
                    if (!response.data.status) {
                        this.auth = false;
                        Event.$emit("checkAuth", window.location.href);
                    } else {
                        this.auth = true;
                    }
                })
                .catch(error => {});
        },

        getProductInfo() {
            axios
                .get("/product/" + this.product)
                .then(response => {
                    response = response.data;
                    if (response.status) {
                        this.products = JSON.parse(response.payload);
                    }
                })
                .catch(error => {});
        },
        checkForm: function(e) {
            if (this.auth) {
                this.errors = [];

                if (!this.form.mobile) {
                    this.errors.push("Mobile  Required*");
                }

                if (!this.form.amount) {
                    this.errors.push("Amount  Required*");
                }

                if (
                    this.form.mobile &&
                    this.form.amount &&
                    this.checkValidNumber()
                ) {
                    this.checkMobileVerified();
                }
            } else {
                this.checkAuth();
            }
            e.preventDefault();
        },
        hideMobileModal() {
            this.mobileVerifyModal = false;
        },
        checkMobileVerified() {
            axios.get("/user/mobile/verify/status").then(response => {
                if (response.data !== "") {
                    var response = response.data;
                    if (response.is_verified == 1) {
                        this.checkBlockedNumber(this.form.mobile);
                    } else {
                        this.errors.push(
                            "Please verify your mobile number first."
                        );
                    }
                } else {
                    this.errors.push("Please verify your mobile number first.");
                    this.mobileVerifyModal = true;
                }
            });
        },
        checkBlockedNumber(number) {
            axios.get("/blockrecharge/check/" + number).then(response => {
                console.log(response.data);
                if (response.data == false) {
                    this.errors.push(
                        "This number is Blocked. Please use another number"
                    );
                }
                if (response.data == true) {
                    this.paymentModel();
                }
            });
        },

        checkValidNumber() {
            if (this.product == "ntc-prepaid") {
                if (!/^([9][8][4-6][0-9]{7})$/.test(this.form.mobile)) {
                    this.errors.push("Enter Valid Ntc Prepaid Number");
                    return false;
                } else {
                    return true;
                }
            } else if (this.product == "ncell") {
                if (!/^([9][8][0-2][0-9]{7})$/.test(this.form.mobile)) {
                    this.errors.push("Enter Valid Ncell  Number");
                    return false;
                } else {
                    return true;
                }
            } else if (this.product == "smartcell") {
                if (
                    !/^([9][6][0-9]{8}|[9][8][8][0-9]{7})$/.test(
                        this.form.mobile
                    )
                ) {
                    this.errors.push("Enter Valid Smart Cell  Number");
                    return false;
                } else {
                    return true;
                }
            } else if (this.product == "nt-cdma") {
                if (!/^([9][7][4-5][0-9]{7})$/.test(this.form.mobile)) {
                    this.errors.push("Enter Valid Nt-Cdma  Number");
                    return false;
                } else {
                    return true;
                }
            } else if (this.product == "nt-postpaid") {
                if (!/^([9][8][5][0-9]{7})$/.test(this.form.mobile)) {
                    this.errors.push("Enter Valid Ntc Postpaid  Number");
                    return false;
                } else {
                    return true;
                }
            }

            return true;
        },
        paymentModel() {
            Event.$emit("full-loader-on");
            this.form.product = this.product;
            this.data = this.form;
            Event.$emit("paypalInit");
            Event.$emit("full-loader-off");
            this.showModal();
        },
        showModal() {
            this.isVisible = true;
        },
        closeModal() {
            this.isVisible = false;
        }
    },
    filters: {
        capitalize: function(value) {
            if (!value) return "";
            value = value.toString();
            return value.charAt(0).toUpperCase() + value.slice(1);
        }
    }
};
</script>
<style scoped>
.error {
    color: red !important;
}
.mobile-modal {
    position: fixed;
    top: 0%;
    left: 0%;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    z-index: 9999;
}
.mobile-modal-body {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 50%;
    background-color: white;
    margin: auto;
}
.mobile-main-body {
    padding: 20px;
}
.mobile-modal-body h5 {
    background-color: #003d9a;
    padding: 10px;
    color: white;
}
.fa-close {
    float: right;
    cursor: pointer;
}
</style>



Route::get('/mobile/verify/status', 'UserController@checkMobileVerifiedStatus');

public function checkMobileVerifiedStatus()
    {

        $user = UserContacts::where('user_id', Auth::user()->id)->first();
        return $user;

    }